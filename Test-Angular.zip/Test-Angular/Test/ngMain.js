var myApp = angular.module('myApp', []);
myApp.controller('myCtrl', ['$scope', function($scope){
	$scope.cardType = '';
}]);

myApp.directive('cardItem', function(){
	switch (cardType){
		case 'qantasDisc':
			templateUrl: 'templates/qantasDisc.html';
			break;

		case 'qantasPrem':
		templateUrl: 'templates/qantasPrem.html';
			break;

		case 'qantasBus':
		templateUrl: 'templates/qantasBus.html';
			break;
	}
});

